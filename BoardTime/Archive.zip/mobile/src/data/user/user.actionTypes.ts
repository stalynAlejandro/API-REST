export const USER_LOGIN = "USER_LOGIN"
export const USER_LOGOUT = "USER_LOGOUT"
export const USER_SINGUP = "USER_SINGUP"
export const USER_LOAD_TASKS = "USER_LOAD_TASKS"
// Estas son los tipos de acciones que tenemos hasta el momento.