# NodeJs + ExpressJS

### Instalar mongodb 

> choco install mongodb

### Crear base de datos local

Añadir C:\Program Files\MongoDB\Server\4.4\bin a **Path**

> mongo

> use my_db

