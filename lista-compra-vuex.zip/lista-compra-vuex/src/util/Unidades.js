var Unidades = Object.freeze({
    KG: 'kg.',
    UD: 'ud.',
    L: 'L.',
    BOTTELLA: 'botellas(s)'
})

export default Unidades;